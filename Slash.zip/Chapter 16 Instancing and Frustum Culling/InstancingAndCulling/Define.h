#pragma once
#include "Macro.h"
#include "Function.h"
#include "Functor.h"

enum HEAP_TYPE
{
	HEAP_DEFAULT,
	HEAP_INSTANCING,
	HEAP_END
};