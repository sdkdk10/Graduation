#pragma once

#include "Component.h"

constexpr	 unsigned long MAXCOLLIDERID = 100000;

class CGameObject;
class GeometryMesh;
class CTransform;

class CCollider
	: public CComponent
{
public:
	enum COLTYPE {COL_AABB, COL_OBB, COL_SPHERE, COL_RECT};
private:
	explicit CCollider(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice);
	explicit CCollider(const CCollider& rhs);
public:
	virtual ~CCollider();

public:
	const wchar_t*			Get_ColTag() { return m_wstrTag; }
	const unsigned long		Get_ColID() { return m_iColliderID; }
	const CGameObject*		Get_Object() { return m_pObject; }
	const BoundingBox*		Get_BoundingBox() { return m_pBoundingBox; }
	const COLTYPE			Get_ColType() { return m_eColType; }
public:
	virtual void Update_Component(const GameTimer& gt);

	// > �Ž����� �ٿ�� �ڽ� �޾ƿ���
	void		Make_Collier(CGameObject* pObj, COLTYPE eType, wchar_t* pTag, BoundingBox* pBox);
	// > �ٿ�� �ڽ� ���� �����
	void		Make_Collier(CGameObject* pObj, COLTYPE eType, wchar_t* pTag, XMFLOAT3& f3Min, XMFLOAT3& f3Max);

	void		Build_Mesh();
private:
	Microsoft::WRL::ComPtr<ID3D12Device>	m_d3dDevice;

	wchar_t*				m_wstrTag = nullptr;
	CGameObject*			m_pObject;
	BoundingBox*			m_pBoundingBox;
	unsigned long			m_iColliderID;
	COLTYPE					m_eColType;

	static unsigned long	m_iAllCollIndex;
	static CCollider*		m_pAllCollider[MAXCOLLIDERID];

	bool					m_isOnce;

	GeometryMesh*			m_pMesh;
	CTransform*				m_pTransform;

public:
	static CCollider* Create(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice);
public:
	virtual CComponent* Clone(void);

protected:
	virtual void Free(void);
};