#pragma once
#include "GameObject.h"

class CCollider;

class Barrel : public CGameObject
{
	typedef struct objdrawelement
	{
		UINT IndexCount = 0;
		UINT StartIndexLocation = 0;
		int BaseVertexLocation = 0;
	}DrawElement;
public:
	Barrel(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice, ComPtr<ID3D12DescriptorHeap> &srv, UINT srvSize);
	virtual ~Barrel();

public:
	virtual bool			Update(const GameTimer & gt);
	virtual void			Render(ID3D12GraphicsCommandList* cmdList);
	virtual HRESULT			Initialize();

private:
	DrawElement				Element_Bounds;
	CCollider*				m_pColliderCom;

public:
	virtual void			RenderBounds(ID3D12GraphicsCommandList* cmdList);

public:
	static Barrel* Create(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice, ComPtr<ID3D12DescriptorHeap> &srv, UINT srvSize);

private:
	virtual void			Free();
};
