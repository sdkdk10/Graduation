#include "stdafx.h"
#include "Barrel.h"
#include "Define.h"
#include "StaticMesh.h"
#include "Transform.h"
#include "Component_Manager.h"
#include "Collision_Manager.h"
#include "Collider.h"


Barrel::Barrel(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice, ComPtr<ID3D12DescriptorHeap> &srv, UINT srvSize) 
	: CGameObject(d3dDevice, srv, srvSize)
	, m_pColliderCom(nullptr)
{
}


Barrel::~Barrel()
{
}

bool Barrel::Update(const GameTimer & gt)
{
	CGameObject::Update(gt);
	m_pMesh->Update(gt);
	m_pColliderCom->Update_Component(gt);
	auto currObjectCB = m_pFrameResource->ObjectCB.get();


	//auto currObjectCB2 = m_pFrameResource->InstanceBuffer.get();

	World._43 = 1.0f;
	XMMATRIX world = XMLoadFloat4x4(&m_pTransCom->GetWorld());
	XMMATRIX texTransform = XMLoadFloat4x4(&TexTransform);

	ObjectConstants objConstants;
	XMStoreFloat4x4(&objConstants.World, XMMatrixTranspose(world));
	XMStoreFloat4x4(&objConstants.TexTransform, XMMatrixTranspose(texTransform));
	objConstants.MaterialIndex = Mat->MatCBIndex;

	currObjectCB->CopyData(ObjCBIndex, objConstants);


	//////////////////////////////////////////////////


	// Next FrameResource need to be updated too.
	//NumFramesDirty--;
	auto currMaterialCB = m_pFrameResource->MaterialCB.get();

	XMMATRIX matTransform = XMLoadFloat4x4(&Mat->MatTransform);

	MaterialConstants matConstants;
	matConstants.DiffuseAlbedo = Mat->DiffuseAlbedo;
	matConstants.FresnelR0 = Mat->FresnelR0;
	matConstants.Roughness = Mat->Roughness;
	XMStoreFloat4x4(&matConstants.MatTransform, XMMatrixTranspose(matTransform));

	matConstants.DiffuseMapIndex = Mat->DiffuseSrvHeapIndex;

	currMaterialCB->CopyData(Mat->MatCBIndex, matConstants);
	return true;
}

void Barrel::Render(ID3D12GraphicsCommandList * cmdList)
{
	UINT objCBByteSize = d3dUtil::CalcConstantBufferByteSize(sizeof(ObjectConstants));
	UINT matCBByteSize = d3dUtil::CalcConstantBufferByteSize(sizeof(MaterialConstants));

	auto objectCB = m_pFrameResource->ObjectCB->Resource();
	auto matCB = m_pFrameResource->MaterialCB->Resource();

	cmdList->IASetVertexBuffers(0, 1, &Geo->VertexBufferView());
	cmdList->IASetIndexBuffer(&Geo->IndexBufferView());
	cmdList->IASetPrimitiveTopology(PrimitiveType);

	CD3DX12_GPU_DESCRIPTOR_HANDLE tex(mSrvDescriptorHeap->GetGPUDescriptorHandleForHeapStart());
	tex.Offset(Mat->DiffuseSrvHeapIndex, mCbvSrvDescriptorSize);

	Mat->DiffuseSrvHeapIndex;
	D3D12_GPU_VIRTUAL_ADDRESS objCBAddress = objectCB->GetGPUVirtualAddress() + ObjCBIndex * objCBByteSize;
	D3D12_GPU_VIRTUAL_ADDRESS matCBAddress = matCB->GetGPUVirtualAddress() + Mat->MatCBIndex*matCBByteSize;

	cmdList->SetGraphicsRootConstantBufferView(4, objCBAddress);
	//cmdList->SetGraphicsRootConstantBufferView(5, matCBAddress);
	cmdList->SetGraphicsRootShaderResourceView(5, matCBAddress);

	cmdList->SetGraphicsRootDescriptorTable(7, tex);

	cmdList->DrawIndexedInstanced(IndexCount, 1, StartIndexLocation, BaseVertexLocation, 0);


	RenderBounds(cmdList);
}

HRESULT Barrel::Initialize()
{
	m_pMesh = new StaticMesh(m_d3dDevice);

	/*if (FAILED(m_pMesh->Initialize(L"Idle", "Models/StaticMesh/staticMesh.ASE")))
		return E_FAIL;*/


	vector<pair<const string, const string>> path;
	path.push_back(make_pair("Idle", "Models/StaticMesh/staticMesh.ASE"));


	if (FAILED(m_pMesh->Initialize(path)))
		return E_FAIL;


	Mat = new Material;
	Mat->Name = "BarrelMat";
	Mat->MatCBIndex = 1;
	Mat->DiffuseSrvHeapIndex = 1;
	Mat->DiffuseAlbedo = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
	Mat->FresnelR0 = XMFLOAT3(0.05f, 0.05f, 0.05f);
	Mat->Roughness = 0.3f;


	m_pTransCom->Translation(10.f, 0.f, 0.f);
	m_pTransCom->Scaling(0.1f, 0.1f, 0.1f);

	XMStoreFloat4x4(&World , XMMatrixScaling(0.1f, 0.1f, 0.1f)*XMMatrixTranslation(0.0f, 1.0f, 0.0f));
	TexTransform = MathHelper::Identity4x4();
	ObjCBIndex = 1;

	Geo = dynamic_cast<StaticMesh*>(m_pMesh)->m_Geometry[0].get();
	PrimitiveType = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
	IndexCount = Geo->DrawArgs["Barrel"].IndexCount;
	StartIndexLocation = Geo->DrawArgs["Barrel"].StartIndexLocation;
	BaseVertexLocation = Geo->DrawArgs["Barrel"].BaseVertexLocation;

	Geo_Bounds = dynamic_cast<StaticMesh*>(m_pMesh)->m_Geometry[1].get();
	PrimitiveType = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
	Element_Bounds.IndexCount = Geo_Bounds->DrawArgs["BarrelBounds"].IndexCount;
	Element_Bounds.StartIndexLocation = Geo_Bounds->DrawArgs["BarrelBounds"].StartIndexLocation;
	Element_Bounds.BaseVertexLocation = Geo_Bounds->DrawArgs["BarrelBounds"].BaseVertexLocation;
	

	///------------------------------- Collider --------------------------
	CComponent* pComponent = nullptr;
	pComponent = m_pColliderCom = (CCollider*)CComponent_Manager::GetInstance()->Clone_Component(L"Com_Collider");
	if (pComponent == nullptr)
		return E_FAIL;
	pComponent->AddRef();
	m_pColliderCom->Make_Collier(this, CCollider::COL_AABB, L"Col_Player", &Geo_Bounds->DrawArgs["BarrelBounds"].Bounds);

	CCollision_Manager::GetInstance()->Add_Bound(m_pColliderCom);

	return S_OK;
}

void Barrel::RenderBounds(ID3D12GraphicsCommandList * cmdList)
{
	//UINT objCBByteSize = d3dUtil::CalcConstantBufferByteSize(sizeof(ObjectConstants));
	cmdList->IASetVertexBuffers(0, 1, &Geo_Bounds->VertexBufferView());
	cmdList->IASetIndexBuffer(&Geo_Bounds->IndexBufferView());
	cmdList->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_LINELIST);

	// Set the instance buffer to use for this render-item.  For structured buffers, we can bypass 
	// the heap and set as a root descriptor.


	cmdList->DrawIndexedInstanced(Element_Bounds.IndexCount, 1, Element_Bounds.StartIndexLocation, Element_Bounds.BaseVertexLocation, 0);
}

Barrel * Barrel::Create(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice, ComPtr<ID3D12DescriptorHeap>& srv, UINT srvSize)
{
	Barrel* pInstance = new Barrel(d3dDevice, srv, srvSize);
	{
		if (FAILED(pInstance->Initialize()))
		{
			MSG_BOX(L"Barrel Created Failed");
			Safe_Release(pInstance);
		}
	}
	return pInstance;
}

void Barrel::Free()
{
}
