#include "stdafx.h"
#include "Collision_Manager.h"
#include "Collider.h"
#include "GameObject.h"


IMPLEMENT_SINGLETON(CCollision_Manager)

CCollision_Manager::CCollision_Manager()
{
}

CCollision_Manager::~CCollision_Manager()
{
}

void CCollision_Manager::Add_Bound(CCollider* pColl)
{
	if (nullptr == pColl)
		return;

	const wchar_t* pTag = pColl->Get_ColTag();
	
	auto finder = m_mapColliderTag.find(pTag);
	
	if (finder == m_mapColliderTag.end())
		m_mapColliderTag.emplace(pTag, unordered_map<unsigned long, CCollider*>());

	if (m_mapColliderTag[pTag].find(pColl->Get_ColID()) == m_mapColliderTag[pTag].end())
		m_mapColliderTag[pTag].emplace(pColl->Get_ColID(), pColl);
}

void CCollision_Manager::Del_Bound(CCollider* pColl)
{
	if (nullptr == pColl)
		return;

	auto pTag = pColl->Get_ColTag();

	auto finder = m_mapColliderTag.find(pTag);
	if (finder == m_mapColliderTag.end())
		return;

	auto collFinder = finder->second.find(pColl->Get_ColID());

	if (collFinder == finder->second.end())
		return;

	finder->second.erase(collFinder);
}

bool CCollision_Manager::Check_Coll_Do_Func(CCollider * pColl, const wchar_t * pTag, function<void(CCollider*, CCollider*, void*)>& _func, bool isDoFuncOnHit, bool isAvoidSameGroup, bool _isOnceCheck)
{
	if (nullptr == pColl)
		return false;

	// �浹ü�� �÷��װ� ���������� �浹Ȯ�� ����.
	if (pColl->IsEnable() == false)
		return false;
	
	auto finder = m_mapColliderTag.find(pTag);

	if (finder == m_mapColliderTag.end())
		return false;

	for (auto& elem : finder->second)
	{
		if (pColl == elem.second)
			continue;

		// �浹 ���Ϸ��� �浹ü�� ������Ʈ���� �÷��װ� ���������� �Ѿ
		if (elem.second->IsEnable() == false || const_cast<CGameObject*>(elem.second->Get_Object())->IsEnable() == false)
			continue;

		CCollider::COLTYPE eSrcType = pColl->Get_ColType();
		CCollider::COLTYPE eDescType = elem.second->Get_ColType();

		if (eSrcType == CCollider::COL_AABB && eDescType == CCollider::COL_AABB)
		{
			if (pColl->Get_BoundingBox()->Intersects(*elem.second->Get_BoundingBox()))
			{
				cout << "-------------------------------------------" << endl;
				cout << pColl->Get_BoundingBox()->Center.x << "\t" << pColl->Get_BoundingBox()->Center.y << "\t" << pColl->Get_BoundingBox()->Center.z << endl;
				cout << pColl->Get_BoundingBox()->Extents.x << "\t" << pColl->Get_BoundingBox()->Extents.y << "\t" << pColl->Get_BoundingBox()->Extents.z << endl;
				cout << elem.second->Get_BoundingBox()->Center.x << "\t" << elem.second->Get_BoundingBox()->Center.y << "\t" << elem.second->Get_BoundingBox()->Center.z << endl;
				cout << elem.second->Get_BoundingBox()->Extents.x << "\t" << elem.second->Get_BoundingBox()->Extents.y << "\t" << elem.second->Get_BoundingBox()->Extents.z << endl;
				cout << "-------------------------------------------" << endl;
				cout << "�浹" << endl;
				return true;
			}
				
		}


	}

	return false;
}

void CCollision_Manager::Free()
{
}
