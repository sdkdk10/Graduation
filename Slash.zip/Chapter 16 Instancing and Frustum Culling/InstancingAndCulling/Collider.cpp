#include "stdafx.h"
#include "Collider.h"
#include "GameObject.h"
#include "Transform.h"
#include "GeometryMesh.h"

CCollider* CCollider::m_pAllCollider[MAXCOLLIDERID] = { nullptr };
unsigned long CCollider::m_iAllCollIndex = 0;

CCollider::CCollider(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice)
	: m_d3dDevice(d3dDevice)
	, m_pObject(nullptr)
	, m_pBoundingBox(nullptr)
{
	while (m_pAllCollider[m_iAllCollIndex++])
	{
		m_iAllCollIndex %= MAXCOLLIDERID;
	}
	m_pAllCollider[m_iAllCollIndex] = this;
	// > ��� �ݶ��̴��� ���� ������ ID�� ������ �ִ�. 
	m_iColliderID = m_iAllCollIndex;
}

CCollider::CCollider(const CCollider& rhs)
	: m_d3dDevice(rhs.m_d3dDevice)
	, m_pBoundingBox(rhs.m_pBoundingBox)
	, m_pObject(rhs.m_pObject)
{
	while (m_pAllCollider[m_iAllCollIndex++])
	{
		m_iAllCollIndex %= MAXCOLLIDERID;
	}
	m_pAllCollider[m_iAllCollIndex] = this;
	// > ��� �ݶ��̴��� ���� ������ ID�� ������ �ִ�. 
	m_iColliderID = m_iAllCollIndex;
}

CCollider::~CCollider()
{
	// > ���� �Ǹ鼭 �迭���� �ڱ� �ڽ��� �����.
	m_pAllCollider[m_iColliderID] = nullptr;
}

CComponent * CCollider::Clone(void)
{
	return new CCollider(m_d3dDevice);
}

void CCollider::Update_Component(const GameTimer & gt)
{
	m_pBoundingBox->Center = m_pObject->GetTransCom()->GetPosition();
}

void CCollider::Make_Collier(CGameObject * pObj, COLTYPE eType, wchar_t * pTag, BoundingBox * pBox)
{
	m_pObject = pObj;
	m_eColType = eType;
	m_wstrTag = pTag;
	m_pBoundingBox = pBox;
	m_pBoundingBox->Extents *= m_pObject->GetTransCom()->GetScale();

	//m_pBoundingBox->Transform(m_pBoundingBox, m_pObject->)
}

void CCollider::Make_Collier(CGameObject * pObj, COLTYPE eType, wchar_t * pTag, XMFLOAT3 & f3Min, XMFLOAT3 & f3Max)
{
	m_pObject = pObj;
	m_eColType = eType;
	m_wstrTag = pTag;


	XMFLOAT3 f3Center = Vector3::Division(Vector3::Add(f3Max, f3Min), 2.0f);
	XMFLOAT3 f3Extent = Vector3::Division(Vector3::Subtract(f3Max, f3Min), 2.0f);

	f3Extent *= m_pObject->GetTransCom()->GetScale();

	m_pBoundingBox->Center = f3Center;
	m_pBoundingBox->Extents = f3Extent;
}

void CCollider::Build_Mesh()
{
	m_pMesh = new GeometryMesh(m_d3dDevice);

	if (FAILED(m_pMesh->Initialize()))
	{
		MSG_BOX(L"CCollider::Build_Mesh Created Failed");
		return;
	}

	/* CB(World,TextureTranform...) Build */

	//XMStoreFloat4x4(&m_pTransform->GetWorld(), XMMatrixScaling(1.0f, 1.0f, 1.0f));
	//ObjCBIndex = 2;

	//Geo = dynamic_cast<GeometryMesh*>(m_pMesh)->m_Geometry[0].get();
	//PrimitiveType = D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
	//IndexCount = Geo->DrawArgs["grid"].IndexCount;
	//StartIndexLocation = Geo->DrawArgs["grid"].StartIndexLocation;
	//BaseVertexLocation = Geo->DrawArgs["grid"].BaseVertexLocation;

}


CCollider * CCollider::Create(Microsoft::WRL::ComPtr<ID3D12Device> d3dDevice)
{
	CCollider* pInstance = new CCollider(d3dDevice);

	return pInstance;
}

void CCollider::Free(void)
{
}
