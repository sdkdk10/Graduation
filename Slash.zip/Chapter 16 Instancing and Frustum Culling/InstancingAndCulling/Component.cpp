#include "stdafx.h"
#include "Component.h"

CComponent::CComponent()
{
}

CComponent::~CComponent()
{
}

void CComponent::Update_Component(const GameTimer & gt)
{
}

void CComponent::Free(void)
{
}
