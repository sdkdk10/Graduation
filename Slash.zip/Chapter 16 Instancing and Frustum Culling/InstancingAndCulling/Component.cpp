#include "stdafx.h"
#include "Component.h"

CComponent::CComponent()
{
}

CComponent::~CComponent()
{
}

void CComponent::Update_Component(/*const CGameTimer & gt*/)
{
}

void CComponent::Free(void)
{
}
